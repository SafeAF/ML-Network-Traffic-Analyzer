class Harddrive < ActiveRecord::Base
	belongs_to :machine
end