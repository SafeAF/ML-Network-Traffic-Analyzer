class Statistic < ActiveRecord::Base
	belongs_to :machine

end
